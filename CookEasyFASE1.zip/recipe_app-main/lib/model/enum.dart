enum MenuType {
  Clock,
  Alarm,
  Timer,
  Stopwatch
}
package com.example.foodrecipe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
